
/**
 * This main class read from text file class
 * @author jenny
 *
 */
public class Main {
	
	 public static void main(String[] args) {
	        String filepath = "project2.txt";
	        
	    readFromFile rff = new readFromFile("project2.txt");
	    
	 }
 
}
